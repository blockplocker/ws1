<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=p, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    require "functions.php";

    ee1(2);
    ee2("kalle", "kanin", "" );
    ee2("harald", "harre", "tjena");
    
    ?>
</body>
</html>