<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    
    <form action="slumpatext($text)" method="post">
    <input type="text" name="texten" value="<?= $text ?>">
    <button type="submit">skicka</button>
    </form>
    <?php


    // slumpatext($text)


        ?>
</body>

</html>

